
# Nama file : NO 3.py
# Deskripsi : Menentukan apakah bujur sangkar atau jajar genjang dan menghitung luas bujur sangkar
# Tanggal : 25 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI TYPE
# type point : <x,y>
    # {<x,y> adalah sebuah point dengan x adalah absis dan y adalah ordinat}
# type segiempat : <a:point,b:point>
    # {<a, b> adalah sebuah segiempat dengan a adalah titik diagonal atas dan b adalah titik diagonal bawah}

# DEFINISI DAN SPESIFIKASI KONSTRUKTOR
# MakePoint : 2 real --> point
    # {MakePoint(x,y) membentuk sebuah point dengan x adalah absis dan y adalah ordinat}
# MakeSegiempat : 2 point --> segiempat
    # {MakeSegiempat(P1,P3) membentuk sebuah segiempat dengan P1 adalah titik diagonal atas dan P3 adalah titik diagonal bawah}

# DEFINISI DAN SPESIFIKASI PREDIKAT 
# isBujurSangkar : segiempat --> boolean
    # {isBujurSangkar(SE) mengecek segiempat SE apakah membentuk sebuah bujur sangkar}
# isJajargenjang : 4 point --> boolean
    # {isJajargenjang(P1,P2,P3,P4) mengecek 4 point apakah membentuk sebuah jajargenjang}

# DEFINISI DAN SPESIFIKASI FUNGSI OPERATOR TERHADAP POINT
# jarak : 2 point --> real
    # {jarak(P1,P2) menghitung jarak kedua point}
# areaBujurSangkar : 4 point --> string
    # {areaBujurSangkar(P1,P2,P3,P4) memberikan string tentang luas bujur sangkar jika 4 point membentuk bujur sangkar}

# REALISASI

def MakePoint(x,y):
    return [x,y]

def Absis(P):
    return P[0]

def MakeSegiempat(P1,P2) :
    return [P1,P2]

def Ordinat(P):
    return P[1]
def jarak(P1,P2):
    return ((Absis(P1) - Absis(P2))**2 + (Ordinat(P1) - Ordinat(P2))**2)**0.5

def isBujurSangkar(SE1,SE2) :
    return jarak(Absis(SE1),Ordinat(SE1)) == jarak(Absis(SE2), 
    Ordinat(SE2)) and jarak(Absis(SE1),Absis(SE2)) == jarak(Ordinat(SE1),Ordinat(SE2))

def isJajargenjang (P1,P2,P3,P4):
    if Absis(P1) - Absis(P4) == Absis(P2) - Absis(P3):
        return   (jarak(P1,P2) == jarak(P3,P4)) and (Absis(P2) - Absis(P3) != 0 and ((Absis(P4) > 
        Absis(P1) and Absis(P3) > Absis(P2)) or (Absis(P4) < Absis(P1) and Absis(P3) < Absis(P2))))
     
def areaBujurSangkar(P1,P2,P3,P4) :
    if(isBujurSangkar(MakePoint(P1,P2),MakePoint(P3,P4))) :
        return f"{jarak(P1,P2)*jarak(P3,P4)} meter"
    else :
        return "Bukan bujur sangkar"
    



# APLIKASI DALAM PYTHON
print(isBujurSangkar(MakeSegiempat(MakePoint(0,3),MakePoint(6,3)),
                     MakeSegiempat(MakePoint(6,-3),MakePoint(0,-3)))) # --> True
print(isJajargenjang(MakePoint(4,6),MakePoint(8,6),
                     MakePoint(10,-1),MakePoint(6,-1))) # --> True
print(areaBujurSangkar(MakePoint(0,3),MakePoint(6,3),
                       MakePoint(5,1),MakePoint(0,1))) # --> Bukan bujur sangkar
print(areaBujurSangkar(MakePoint(0,3),MakePoint(6,3),
                       MakePoint(6,-3),MakePoint(0,-3))) # --> 36.0 meter

