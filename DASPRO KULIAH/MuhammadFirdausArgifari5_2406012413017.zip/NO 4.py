


# Nama file : NO 4.py
# Deskripsi :  Htung range nilai
# Tanggal : 30 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# DEFINISI DAN SPESIFIKASI TYPE
# type MHS1 : <NIM:integer, Nama:string, TanggalLahir:string>
    # {<NIM, Nama, TanggalLahir> adalah data mahasiswa dengan NIM, nama, dan tanggal lahir}
# type MHS2 : <NIM:integer, KodeMatkul:string, Nilai:real>
    # {<NIM, KodeMatkul, Nilai> adalah data mahasiswa dengan NIM, kode matkul, dan nilai}
# type MHS3 :<KodeMatkul:string, NamaMatkul:string>
    # {<KodeMatkul, NamaMatkul> adalah data mahasiswa dengan kode matkul dan nama matkul}

# DEFINISI DAN SPESIFIKASI SELEKTOR
# KodeMatkul : MHS2 --> string
    # {KodeMatkul(MHS2) memberikan kode matkul dari MHS2 yang terdiri dari <NIM, KodeMatkul, Nilai>}
# Nilai : MHS2 --> real
    # {Nilai(MMHS2) memberikan nilai dari MHS2 yang terdiri dari <NIM, KodeMatkul, Nilai>}

# DEFINISI DAN SPESIFIKASI KONSTRUKTOR
# MakeMHS1 : integer, string, string --> MHS1
    # {MakeMHS1(NIM, Nama, TanggalLahir) membentuk tipe bentukan MHS1}
# MakeMHS2 : integer, string, integer --> MHS2
    # {MakeMHS2(NIM, KodeMatkul, Nilai) membentuk tipe bentukan MHS2}
# MakeMHS3 : 2 string --> MHS3
    # {MakeMHS3(KodeMatkul, NamaMatkul) membentuk tipe bentukan MHS3}

# DEFINISI DAN SPESIFIKASI FUNGAU OPERATOR
# max2 : 2 integer --> integer 
    # {max2(a,b) mengembalikan nilai terbesar dari 2 nilai}
# max4 : 4 integer --> integer
    # {max4(a,b,c,d) memberikan nilai terbesar dari 4 nilai}
# min2 : 2 integer --> integer
    # {min2(a,b) memberikan nilai terkecil dari 2 nilai}
# min4 : 4 integer --> integer
    # {min4(a,b,c,d) memberikan nilai terkecil dari 4 nilai}
# hitungRangeNilai : 4 MHS2 --> date
    # {hitungRangeNilai(MHS20,MHS21,MHS22,MHS234) mmemberikan pajaak}
# REALISASI

def MakeMHS1(NIM, Nama, TanggalLahir) :
    return [NIM,Nama,TanggalLahir]

def MakeMHS2(NIM, KodeMatkul, Nilai) :
    return [NIM, KodeMatkul, Nilai]

def MakeMHS3(KodeMatkul, NamaMatkul) :
    return [KodeMatkul, NamaMatkul]

def MakeRangeNilai(KodeMatkul, NilaiTertinggi, NilaiTerendah, RangeNilai):
    return [KodeMatkul, NilaiTertinggi, NilaiTerendah, RangeNilai]

def KodeMatkul(MHS2):
    return MHS2[1]

def Nilai(MHS2):
    return MHS2[2]

def max2(a,b):
    return (a + b + abs(a - b)) // 2

def max4(a,b,c,d):
    return max2(max2(a,b),max2(c,d))

def min2(a,b):
    return (a + b - abs(a - b)) // 2

def min4(a,b,c,d) :
    return min2(min2(a,b),min(c,d))


def hitungRangeNilai(MHS20,MHS21,MHS22,MHS23) :
    return MakeRangeNilai(KodeMatkul(MHS20),max4(Nilai(MHS20), Nilai(MHS21),
    Nilai(MHS22), Nilai(MHS23)), min4(Nilai(MHS20), Nilai(MHS21), Nilai(MHS23), Nilai(MHS22)), 
    max4(Nilai(MHS20), Nilai(MHS21), Nilai(MHS22), Nilai(MHS23)) - 
    min4(Nilai(MHS20), Nilai(MHS21), Nilai(MHS23), Nilai(MHS22)))


# APLIKASI 
print(
    f"""Range Nilai: {
        hitungRangeNilai(
            
    MakeMHS2(24060124110142, "69", 100),
    MakeMHS2(24060124110142, "69", 43),
    MakeMHS2(24060124110142, "69", 76),
    MakeMHS2(24060124110142, "69", 69),
            
    )}"""
)  # -> Range Nilai: ['69', 100, 43, 57]
