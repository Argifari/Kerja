
# Nama File : NO 2.py
# Deskripsi : Tipe bentukan garis
# Tanggal   : 25 September 2024
# Pembuat   : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI TYPE
# type point : <x:real, y:real>
    # {<x,y> adalah sebuah point, dengan x adalah absis dan y adalah ordinat}
# type line : <P1:point, P2:point>
    # {<P1, P2> adalah sebuah line dengan dua point}

# DEFINISI DAN SPESIFIKASI KONSTRUKTOR
# MakePoint : 2 real --> point
    # {MakePoint(x,y) membentuk sebuah point dari x sebagai absis dan y sebagai ordinat}
# MakeLine : 2 point --> line
    # {MakeLine(P1,P2) membentuk sebuah line dari kedua point}

# DEFINISI DAN SPESIFIKASI SELEKTOR
# Absis : point --> real
    # {Absis(P) memeberikan nilai absis dari point P}
# Ordinant : point --> real
    # {Ordinat(P) memberikan nilai ordinat dari point P}

# DEFINISI DAN SPESIFIKASI PREDIKAT
# IsSejajar : 2 line --> boolean
    # {IsSejajar(L1,L2) benar jika kedua line sejajar}

# DEFINISI DAN SPESIFIKASI FUNSGI OPERATOR TERHADAP POINT
# PanjangGaris : 2 point --> real
    # {PanjangGaris(P1,P2) menghitung jarak 2 point}

# REALISASI DALAM PYTHON

def MakePoint(x,y):
    return [x,y]

def Absis(P) :
    return P[0]

def Ordinat(P):
    return P[1]

def MakeLine(P1,P2) :
    return [P1,P2]

def IsSejajar(L1,L2) :
    if Absis(Absis(L1)) - Absis(Ordinat(L1)) == 0 :
        if Absis(Absis(L2)) - Absis(Ordinat(L2)) == 0:
            return True
        else:
            return False
    elif Ordinat(Absis(L1)) - Ordinat(Ordinat(L1)) == 0 :
        if Ordinat(Absis(L2)) - Ordinat(Ordinat(L2)) == 0:
            return True
        else:
            return False
    else :
        return ((Ordinat(Absis(L1)) - Ordinat(Ordinat(L1))) / 
                (Absis(Absis(L2)) - Absis(Ordinat(L2)))) == ((Ordinat(Absis(L2)) - Ordinat(Ordinat(L2)))
                 / (Absis(Absis(L2)) - Absis(Ordinat(L2))))
            
        

def PanjangGaris(P1,P2) :
    return ((Absis(P1) - Absis(P2))**2 + (Ordinat(P1) - Ordinat(P2))**2)**0.5

# APLIKASI DALAM PYTHON

print(IsSejajar(MakeLine(MakePoint(0,3),MakePoint(4,3)),MakeLine(MakePoint(3,0),MakePoint(0,3)))) # --> False
print(PanjangGaris(MakePoint(4,3),MakePoint(5,2))) # --> 1.4142135623730951