
# Nama file : NO 5.py
# Deskripsi : Menentukan apakah urutan angka x terulang tersebut sesuai dengan desimal hasil pembagian 1 dengan sebuah bilangan bulat.
# Tanggal : 22 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# denumeratorSeq : string --> string
    # denumeratorSeq(x) Menentukan apakah urutan angka x terulang tersebut sesuai dengan desimal hasil pembagian 1 dengan sebuah bilangan bulat.

#REALISASI

def denumeratorSeq(x) :
    if ((10**(len(x)) - 1)/int(x)) % 1 == 0:
        return f'Ada: {int(((10**(len(x)) - 1)/int(x)))}'
    return "Tidak ada"

#APLIKASI

print(denumeratorSeq('3')) # --> Ada: 3
print(denumeratorSeq('166')) # -- > Tidak ada
print(denumeratorSeq('11')) # --> Ada: 9

