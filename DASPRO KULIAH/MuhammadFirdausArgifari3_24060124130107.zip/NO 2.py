
# Nama File : NO2.py
# Deskripsi : menganalisa data pesawat untuk mencegah kecelakaan dan menjaga efisiensi operasional di bandara
# Tanggal   : 22 September 2024
# Pembuat   : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# monitor_pesawat : 3integer --> string
    # monitor_pesawat(x,y,z) mengeluarkan string dengan x,y,z harus memenuhi syarat

#REALISASI

def monitor_pesawat(x,y,z):
    if (y > 900) or (y < 200) :
        return "Kecepatan Berbahaya"
    elif (x > 12000) :
        return "Terlalu Tinggi"
    elif (z < 20) :
        return "Bahan Bakar Rendah"
    elif(x < 5000) and (200 <= y <= 900) and (z > 50):
        return "Aman untuk Mendarat"
    else :
        return "Berjalan Normal"
    
#APLIKASI

print(monitor_pesawat(5000,950,70)) # --> Kecepatan Berbahaya
print(monitor_pesawat(4000,300,40)) # --> Berjalan Normal
print(monitor_pesawat(2500,500,100)) #--> Aman untuk Mendarat