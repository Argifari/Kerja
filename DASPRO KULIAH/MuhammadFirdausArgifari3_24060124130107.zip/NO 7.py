
# Nama file : NO 7.py
# Deskripsi : menghitung harga akhir
# Tanggal : 22 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# hargaAkhir : integer,string,boolean,string,string --> integer
    # hargaAkhir(harga,kategori,VIP,lokasi,hari) menghitung harga akhir setelah pemberian pajak atau diskon

# pajakTempat : string,integer --> real
    # pajakTempat(a,harga) menghitung harga setelah terkena pajak tempat dalam negeri atau di luar negeri

# harian : 3string,integer --> real
    # harian(a,b,c,harga) menghitung harga setelah terkena pajak hari dan diskon hari jika memenuhi syarat


#REALISASI

def pajakTempat(a,harga):
    if a == "dalam negeri":
        return harga + harga*10/100
    else : 
        return harga + harga*20/100

def harian(a,b,c,harga) :
    if a == "Jumat" or a == "Sabtu" :
        if b :
            return harga - harga*5/100
    elif a == "Minggu":
        return harga + harga*5/100
    elif a == "Rabu" :
        if c == "pakaian" :
            return harga - harga*5/100
    else :
        return harga

def hargaAkhir(harga,kategori,VIP,lokasi,hari) :
    if kategori == "elektronik":
        if VIP :
            return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga - harga*30/100)))
        else :
            return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga - harga*10/100)))
    elif kategori == "pakaian":
        if VIP :
            return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga - harga*20/100)))
        else :
            return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga - harga*5/100)))
    elif kategori == "makanan" :
        if VIP :
            return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga - harga*15/100)))
        else :
            return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga - harga*2/100)))
    return int(harian(hari,VIP,kategori,pajakTempat(lokasi,harga)))

#APLIKASI

print(hargaAkhir(1000000, "elektronik", True, "dalam negeri", "Senin")) # --> 770000
print(hargaAkhir(500000,"baju", True,"luar negeri","Minggu")) # --> 630000
print(hargaAkhir(7666000,"elektronik", True, "dalam negeri","Senin")) # --> 5902820