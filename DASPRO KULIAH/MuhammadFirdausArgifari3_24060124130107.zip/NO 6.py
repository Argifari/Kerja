
# Nama file : NO 6.py
# Deskripsi : Menemukan gradien magis antara kedua titik menggunakan rumus
# Tanggal : 22 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# gradien : 2integer --> real
    # gradien(a,b) Menenmukan gradien magin antara kedua titik menggunakan rumus
# f : integer --> integer
    # f(x) menghitung x ke dalam rumus 3*x^2 + 2*x - 5


#REALISASI

def f(x) :
    return 3*x**2 + 2*x - 5

def gradien(a,b) :
    return (f(a) - f(b))/(a-b)


#APLIKASI

print(gradien(4,5)) # --> 29.0
print(gradien(9,1)) # --> 32.0
print(gradien(3,1)) # --> 14.0
