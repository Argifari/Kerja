
# Nama file : NO 7.py
# Deskripsi : menghitung estimasi perbandingan pengunjung perpustakaan
# Tanggal : 22 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# EstimateGreatLib : string, 8integer --> real
    # EstimateGreatLib(D,X,Y,SS,SR,AS,AM,AIP,R) menghitung estimasi perbandingan pengunjung dalam hari (D) dalam jenjang waktu X sampai Y

#hitung : string --> real
    #hitung(D) menghitung jumlah rata - rata pengunjung dalam 3 pekan sebelumnya

#REALISASI

def hitung(D) :
    rata = 0
    if D == "senin":
        rata = (5000 + 6000 + 4000)/3
    elif D == "selasa":
        rata = (7000 + 5000 + 2000)/3
    elif D == "rabu":
        rata = (4500 + 3500 + 3000)/3
    elif D == "kamis":
        rata = (2900 + 2100 + 2000)/3
    elif D == "jumat":
        rata = (3000 + 3000 + 3000)/3
    elif D == "sabtu":
        rata = (2000 + 2500 + 2300)/3
    elif D == "minggu":
        rata = (1100 + 900 + 1000)/3

    return rata

def EstimateGreatLib(D,X,Y,SS,SR,AS,AM,AIP,R):
    ans = 0
    if (X >= SR and X <= SS) and (Y >= SR and Y <= SS) :
        # print('masuk')
        ans = (Y - X)*(max(AIP,AM,AS) - min(AIP,AS,AM))/hitung(D)
        return round(ans,5)
    elif (Y > SR and Y <= SS) and (X < SR) :
        # print('masuk')
        ans = ((SR - X)*R/100 + (Y - SR))*(max(AIP,AM,AS) - min(AIP,AS,AM))/hitung(D)
        # print('masuk')
        return round(ans/2,5)
    elif (X >= SR and X < SS) and (Y > SS) :
        # print('masuk')
        ans = ((SS - X) + (Y - SS)*R/100)*(max(AIP,AM,AS) - min(AIP,AS,AM))/hitung(D)
        return round(ans/2,5)
    elif ((X >= SS) and (Y > SS)) or ((X < SR) and (Y <= SR)) :
        # print('masuk')
        ans = (Y - X)*R/100*(max(AIP,AM,AS) - min(AIP,AS,AM))/hitung(D)
        return round(ans,5)
    elif (Y > SS) and (X < SR) :
        ans = ((SR - X)*R/100 + (SS - SR) + (Y - SS)*R/100)*(max(AIP,AM,AS) - min(AIP,AS,AM))/hitung(D)
        return round(ans/3,5)


#APLIKASI 
print(EstimateGreatLib("sabtu",4,5,21,9,4000, 5500, 5000, 3)) # --> 0.01985
print(EstimateGreatLib("jumat",9,17,20,5,4000, 5500, 5000, 3)) # --> 4.0
print(EstimateGreatLib("minggu",4,18,17,5,4000, 5500, 5000, 3)) # --> 6.03

