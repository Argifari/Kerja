
# Nama File : NO 1.py
# Deskripsi : menghitung waktu dengan presisi
# Tanngal   : 22 September 2024
# Pembuat   : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
#jam : integer[0..24], integer[0..59],integer[0..59] --> string
    #jam(j,m,s) jika benar akan mengeluarkan string yang berisi "Jam: (j), Menit: (m), Detik: (s)", jika tidak sesuai syarat maka akan mengeluarkan string "Waktu tidak valid"

#REALISASI

def jam (j,m,s) :
    if (0 <= j <= 24) and (0 <= m <= 59) and (0 <= s <= 59) :
        return f"Jam: {j}, Menit: {m}, Detik: {s}"
    return "Waktu tidak valid"

#APLIKASI
print(jam(12,30,45))   
print(jam(12,45,60))