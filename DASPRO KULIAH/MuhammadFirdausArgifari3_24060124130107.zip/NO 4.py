


# Nama file : NO 4.py
# Deskripsi : menghitung jarak agar bisa belajar dengan tenang 
# Tanggal : 22 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# DEFINISI DAN SPESIFIKASI
# BelajarTenang : 2integer --> string
    # BelajarTenang(dB,m) menghitung jarak agar bisa belajar dengan tenang. Fungsi akan mengeluarkan string "x meter" jika kurang dari sama dengan m,
        # jika lebih dari m maka akan keluar string "Isi bensin dulu, bang"

# REALISASI

def BelajarTenang (dB,m):
    x = round(15 * 10**((dB - 40)/20),3)
    if x > m :
        return "Isi bensin dulu, bang"
    return f'{x} meter'

# APLIKASI 

print(BelajarTenang(102,20000)) #--> 18883.881 meter
print(BelajarTenang(100,1300)) # --> Isi bensin dulu, bang
print(BelajarTenang(70,200)) # --> Isi bensin dulu,bang
