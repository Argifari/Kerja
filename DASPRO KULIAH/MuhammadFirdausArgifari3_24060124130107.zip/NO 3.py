

# Nama file : NO 3.py
# Deskripsi : menentukan jalan semut yang paling cepat
# Tanggal : 22 September 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# DEFINISI DAN SPESIFIKASI
# jalanSemut : 3integer --> real
    # jalanSemut(x,y,z) menghitung jarak terpendek yang bisa ditempuh semut untuk mencapai gula dengan semut diasumsikan berada di (0,0,0)

# REALISASI

def jalanSemut(x,y,z):
    ans1 = ((x+y)**2 + z**2)**0.5
    ans2 = ((x+z)**2 + y**2)**0.5
    ans3 = ((y+z)**2 + x**2)**0.5

    return round(float(min(ans1,ans2,ans3)),3)

# APLIKASI

print(jalanSemut(3,4,5)) # --> 8.602
print(jalanSemut(1,2,7)) # --> 7.616
print(jalanSemut(8,4,10)) # --> 15.62