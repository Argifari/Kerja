
# Nama File : NO2.py
# Deskripsi : menghitung jumlah hari dari tanggal 1 Januari dengan memperhitungkan tahun kabisat
# Tanggal   : 10 September 2024
# Pembuat   : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# Harike : integer[1..31], integer[1..12],integer[0..9999] --> integer[1..366]
    #{Harike1900(d,m,y) menghitung hari dari awal tahun (y) yaitu 1 Januari dari suatu tanggal(d) dan bulan (m)}

#isKabisat : integer[0..9999] --> boolean
    #{isKabisat(y) bernilai True jika (y) habis dibagi 4 tetapi tidak habis dibagi 100 atau habis dibagi 400}

#dpm : integer[1..12] --> integer[1..355]
    #{dpm(b) jumlah hari yang terhitung dari 1 Januari pada tanggal 1 bulan (b)}

#REALISASI

def dpm (b) : 
    if b == 1:
        return 1
    elif b == 2:
        return 32
    elif b == 3:
        return 60
    elif b == 4 : 
        return 91
    elif b == 5:
        return 121
    elif b == 6:
        return 152
    elif b == 7:
        return 182
    elif b == 8:
        return 213  
    elif b == 9:
        return 244
    elif b == 10:
        return 274
    elif b == 11:
        return 305
    elif b == 12 :
        return 335

def isKabisat (y):
    if ((y % 4 == 0) and (y % 100 != 0)) or (y % 400 == 0) :
        return True
    else :
        return False
    
def Harike (d,m,y):
    if isKabisat(y) and m > 2:
        return dpm(m) + d
    else :
        return dpm(m) + d - 1

#APLIKASI
print(Harike(10,3,2000))
print(Harike(10,3,2001))