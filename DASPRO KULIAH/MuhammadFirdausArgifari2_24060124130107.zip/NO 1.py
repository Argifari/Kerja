
# Nama File : NO1.py
# Deskripsi : Menghitung jumlah hari dari tanggal 1 Januari di tahun terkait dengan tidak memperhitungkan tahun kabisat
# Tanngal   : 10 September 2024
# Pembuat   : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# Harike : integer[1..31], integer[1..12],integer[0..9999] --> integer[1..366]
    #{Harike(d,m,y) menghitung hari dari awal tahun (y) yaitu 1 Januari dari suatu tanggal(d) dan bulan (m)}

# dpm : integer[1..12] --> integer[1..355] 
    #{dpm(b) jumlah hari yang terhitung dari 1 Januari pada tanggal 1 bulan (b)}


#REALISASI

def dpm (b) : 
    if b == 1:
        return 1
    elif b == 2:
        return 32
    elif b == 3:
        return 60
    elif b == 4 : 
        return 91
    elif b == 5:
        return 121
    elif b == 6:
        return 152
    elif b == 7:
        return 182
    elif b == 8:
        return 213  
    elif b == 9:
        return 244
    elif b == 10:
        return 274
    elif b == 11:
        return 305
    elif b == 12 :
        return 335

def Harike(d,m,y) :
    return dpm(m) + d - 1

#APLIKASI
print(Harike(10,3,2000))
print(Harike(10,3,2001))