


# Nama file : NO 4.py
# Deskripsi : Mengecek sebuah angka, benar jika angka teresbut lebih kecil 5 atau lebih besar dari 500
# Tanggal : 28 Agustus 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# DEFINISI DAN SPESIFIKASI
# isValid : integer --> boolean
    # isValid(x)? benar jika (x) bernilai lebih kecil dari 5 atau lebih besar dari 500

# REALISASI

def isValid (x) :
    if (x < 5) or (x > 500) :
        return True
    return False



# APLIKASI 

print(isValid(1))