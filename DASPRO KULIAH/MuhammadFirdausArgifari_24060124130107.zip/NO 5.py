
# Nama file : NO 5.py
# Deskripsi : menentukan jarak 2 titiks
# Tanggal : 28 Agustus 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107


# DEFINISI DAN SPESIFIKASI
# LS : real --> real
    # LS(x1,y1,x2,y2) menghitung jarak antara dua buah titik (x1,y1) dengan (x2,y2)
# dif : real --> real
    # dif(x1,x2) menghitung kuadrat dari selisih 2 titik (x2 - x1)
# fx2 : real --> real
    # fx2(x) hasil kuadrat dari (x)


#REALISASI
from math import sqrt
def fx2 (x) :
    return x*x

def dif (x1,x2) :
    return fx2(x2 - x1)

def LS (x1,y1,x2,y2) :
    return sqrt(dif(x1,x2) + dif(y1,y2))




#APLIKASI

print(LS(1,3,5,6))