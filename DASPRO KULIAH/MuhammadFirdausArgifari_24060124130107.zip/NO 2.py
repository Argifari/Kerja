
# Nama file : NO 2.py
# Deskripsi : mengecek nilai x apakah positif
# Tanggal : 28 Agustus 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# DEFINISI DAN SPESIFIKASI
# isPositif : integer --> boolean
    # isPositif(a) mengecek 1 bilangan apakah bilangan itu positif atau bukan, jika positif, maka benar.


#REALISASI
def isPositif (a) :
    if a >= 0 : 
        return True
    
    return False



#APLIKASI

print(isPositif(1))