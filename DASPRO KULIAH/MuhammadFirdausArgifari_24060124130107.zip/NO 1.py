
# Nama file : N0 1.py
# Deskripsi : menghitung nilai rata - rata dari bilangan yang bukan maksimum dan bukan minimum 
# Tanggal : 27 Agustus 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# Defini dan spesifikasi :
# MO : integer >= 0 --> real
    # MO(a,b,c,d) menentukan rata-rata dari 2 buah bilangan integer yang bukan maksimum dan bukan minimum dari 4 buah bilangan :
        # (a + b + c + d - min4(a,b,c,d) - max4(a,b,c,d)) / 2

# max4 : integer > 0 --> integer
    # max4(a,b,c,d) menentukan maksimum dari 4 buah bilangan

# max2 : integer > 0 --> integer
    # max2 (a,b) menentukan maksimum dari 2 buah bilangan

# min4 : integer > 0 --> integer
    # min4(a,b,c,d) menentukan minimum dari 4 buah bilangan

# min2 : integer > 0 --> integer
    # min2(a,b) menentukan minimum dari 2 buah bilangan

#REALISASI

def max2 (a,b) :
    return ((a + b) + abs(a - b)) // 2

def min2 (a,b) :
    return ((a + b) - abs(a - b)) // 2

def min4 (a,b,c,d) :
    return min2(min2(a,b),min2(d,c))

def max4(a,b,c,d) :
    return max2(max2(a,b),max2(c,d))

def MO (a,b,c,d) :
    return ((a+b+c+d) - max4(a,b,c,d) - min4(a,b,c,d)) / 2

#APLIKASI

print(MO(8,12,10,20))

