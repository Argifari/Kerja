

# Nama file : NO 3.py
# Deskripsi : mengecek sebuah character apakah character itu 'A'
# Tanggal : 28 Agustus 2024
# Pembuat : Muhammad Firdaus Argifari 24060124130107

# DEFINISI DAN SPESIFIKASI
# isAnA : character --> boolean
    # isAnA(c) mengecek 1 character apakah character itu huruf 'A', bernilai benar jika c adalah character huruf 'A'

# REALISASI

def isAnA (c) :
    if (c == 'A') :
        return True
    
    return False

# APLIKASI

print(isAnA(1))